import { Avatar, AvatarFallback } from "../ui/avatar";
import { Card } from "../ui/card";

interface Props {
  data: Product;
}

export function Product({ data }: Props) {
  return (
    <Card
      style={{ backgroundImage: `url(${data.images[0]})` }}
      className=" h-60 bg-cover text-white bg-center bg-no-repeat flex p-0"
    >
      <div className="bg-black/40 flex-1 flex flex-col justify-end p-4">
        <h4 className="text-xl font-medium">{data.title}</h4>
        <p className="text-xs font-light">{data.description}</p>
      </div>
    </Card>
  );
}
